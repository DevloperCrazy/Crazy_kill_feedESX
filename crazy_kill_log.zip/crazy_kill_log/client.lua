AddEventHandler('gameEventTriggered', function(name, args)
    if name == "CEventNetworkEntityDamage" then
        local victim = tonumber(args[1])
        local attacker = tonumber(args[2])

        -- If YOU are the attacker and the victim is a player
        if attacker == PlayerPedId() and IsEntityAPed(victim) and IsPedAPlayer(victim) then
            -- Check if the victim actually died
            if IsEntityDead(victim) then
                local victimId = NetworkGetPlayerIndexFromPed(victim)
                TriggerServerEvent('killLog:playerDied', GetPlayerServerId(victimId))
            end
        end
    end
end)

-- Killer notification
RegisterNetEvent('killLog:showNotificationKiller')
AddEventHandler('killLog:showNotificationKiller', function(victimName, victimId)
    exports['okokNotify']:Alert("Kill Log", "You killed " .. victimName .. " (id:" .. victimId .. ")", 5000, 'success')
end)

-- Victim notification
RegisterNetEvent('killLog:showNotificationVictim')
AddEventHandler('killLog:showNotificationVictim', function(killerName, killerId)
    exports['okokNotify']:Alert("Kill Log", "You were killed by " .. killerName .. " (id:" .. killerId .. ")", 5000, 'error')
end)