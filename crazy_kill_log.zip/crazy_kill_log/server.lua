RegisterServerEvent('killLog:playerDied')
AddEventHandler('killLog:playerDied', function(victimId)
    local killer = source -- killer is the event source
    local victim = victimId

    if killer and victim and killer ~= victim then
        local killerName = GetPlayerName(killer)
        local victimName = GetPlayerName(victim)

        -- Notify the killer
        TriggerClientEvent('killLog:showNotificationKiller', killer, victimName, victim)

        -- Notify the victim
        TriggerClientEvent('killLog:showNotificationVictim', victim, killerName, killer)
    end
end)