shared_script "@ReaperV4/imports/bypass.lua"
shared_script "@ReaperV4/imports/bypass_s.lua"
shared_script "@ReaperV4/imports/bypass_c.lua"
lua54 "yes" -- needed for Reaper

fx_version 'cerulean'
game 'gta5'

author 'Crazy'
description 'Kill Log Notification'
version '1.0.0'
---MADE BY CRAZY---

client_scripts {
    'client.lua'
}

server_scripts {
    'server.lua'
}